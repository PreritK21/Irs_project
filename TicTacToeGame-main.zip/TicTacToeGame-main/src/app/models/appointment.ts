export interface Appointment {
    id:number,
    title:string,
    date:Date
}
